package com.perubdev.nmpinformaticse_sport

data class PlayerBank(
    var name: String,
    var role: String,
    var profileImageId: Int
)
