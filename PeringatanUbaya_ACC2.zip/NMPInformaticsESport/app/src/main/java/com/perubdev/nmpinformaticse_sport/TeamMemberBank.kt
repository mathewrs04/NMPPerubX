package com.perubdev.nmpinformaticse_sport


data class TeamMemberBank(
    var name: String,
    var members: List<PlayerBank>
)
