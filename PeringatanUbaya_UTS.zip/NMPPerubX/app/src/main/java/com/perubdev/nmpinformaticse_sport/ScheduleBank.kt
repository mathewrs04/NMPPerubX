package com.perubdev.nmpinformaticse_sport

data class ScheduleBank(
        var event: String,
        var date: String,
        var place: String,
        var imageId: Int,
        var time: String,
        var team:String,
        var description: String
)