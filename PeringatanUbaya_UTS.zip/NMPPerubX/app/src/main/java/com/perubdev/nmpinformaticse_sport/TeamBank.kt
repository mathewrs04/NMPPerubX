package com.perubdev.nmpinformaticse_sport


data class TeamBank(
    var name: String,
    var members: Array<PlayerBank>
)
