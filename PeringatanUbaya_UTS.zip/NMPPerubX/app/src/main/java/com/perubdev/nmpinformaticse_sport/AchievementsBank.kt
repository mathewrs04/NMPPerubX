package com.perubdev.nmpinformaticse_sport

data class AchievementsBank (
    var game: String,
    var achievements: String,
    var year: Int,
    var team: String
)